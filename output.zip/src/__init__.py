"""
Core package for the recognition system.
Version and basic package information.
"""
__version__ = '1.0.0'
__author__ = 'Ziyuan Li'
